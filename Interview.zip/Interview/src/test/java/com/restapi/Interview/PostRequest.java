package com.restapi.Interview;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostRequest {

	@Test
	public void verifyPostRequest(){
		 // Specify the base URL to the RESTful web service
		 RestAssured.baseURI = "https://reqres.in/api";
		 
		 // Get the RequestSpecification of the request that you want to sent
		 // to the server. The server is specified by the BaseURI that we have
		 // specified in the above step.
		 RequestSpecification httpRequest = RestAssured.given();
		
	//Form Request payload	 
		JSONObject requestParams = new JSONObject();
		 requestParams.put("name", "darth veder"); // Cast
		 requestParams.put("job", "villaen");
	
		 
		 httpRequest.body(requestParams.toJSONString());
		 Response response = httpRequest.post("/users");
	
	//Get response code and verify	 
		 int statusCode = response.getStatusCode();
		 Assert.assertEquals(statusCode, 201);
		 
	}
}
